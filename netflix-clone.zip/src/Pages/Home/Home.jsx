// import React from "react";
import "./Home.css";
import Navbar from "../../Components/Navbar/Navbar";
import hero_banner from "../../assets/hero_banner.jpg";
import hero_tittle from "../../assets/hero_title.png";
import play_icon from "../../assets/play_icon.png";
import info_icon from "../../assets/info_icon.png";
import Tittlecards from "../../Components/TittleCards/Tittlecards";
import Footer from "../../Components/Footer/Footer";

const Home = () => {
  return (
    <div className="home">
      <Navbar />
      <div className="hero">
        <img src={hero_banner} alt="" className="banner-img" />
        <div className="hero-caption">
          <img src={hero_tittle} alt="" className="caption-img" />
          <p>
            Discovering his ties to a secret ancidet order, a young man living
            in modern <br /> Istanbol embarks on a quest to save the city from an
            ammorttal enemy
          </p>
          <div className="hero-btn">
            <button className="btn"><img src={play_icon} alt="" />Play </button>
            <button className="btn dark-btn"><img src={info_icon} alt="" />More Info </button>

          </div>
          <Tittlecards/>
        </div>
      </div>
      <div className="more-cards">
      <Tittlecards title={"Blockbuster Movies "}  category={"top_rated"} />
      <Tittlecards  title={"Only on NetFlix "}  category={"popular"} />
      <Tittlecards title={"Upcoming "}  category={"upcoming"} />
      <Tittlecards title={"Top Pics for you"}  category={"now_playing"} />


      </div>
      <Footer/>
    </div>
  );
};

export default Home;
